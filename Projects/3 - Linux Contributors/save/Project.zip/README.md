# Coding a Webpage

Just a simple carousel of some contributors of linux, you can see [here](https://github.com/LoucasMaillet/NSI)